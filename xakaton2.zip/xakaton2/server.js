import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

import creatorRoutes from "./src/routes/creatorRoutes.js";
import errorHandler from "./src/middleware/errorHandler.js";
import requestLogger from "./src/middleware/requestLogger.js";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

app.use(cors());
app.use(express.json());
app.use(requestLogger);

app.use("/api/creators", creatorRoutes);

app.use(express.static(__dirname));

app.use(errorHandler);

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`CreatorFlow backend running on http://localhost:${PORT}`);
});
