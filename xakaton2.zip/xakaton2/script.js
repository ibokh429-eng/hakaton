const API_BASE = "/api/creators";

const modal = document.getElementById("demoModal");
const demoResult = document.getElementById("demoResult");

function startDemo() {
  modal.classList.add("show");
  demoResult.style.display = "none";
}

function closeDemo() {
  modal.classList.remove("show");
}

function selectCreator(type) {
  fetch(`${API_BASE}/${type}`)
    .then((res) => {
      if (!res.ok) throw new Error("Creator not found");
      return res.json();
    })
    .then((response) => {
      const data = response.data;

      modal.classList.add("show");
      demoResult.style.display = "block";

      demoResult.innerHTML = `
        <div style="
          color:#a991ff;
          font-weight:800;
          margin-bottom:10px;
        ">
          ${data.title}
        </div>

        <b>AI vazifasi:</b><br>
        ${data.aiTask}
        <br><br>
        <strong>${data.stepsBefore} qadam → ${data.stepsAfter} qadam</strong>
      `;
    })
    .catch((err) => {
      console.error(err);
    });
}

window.addEventListener("click", function (event) {
  if (event.target === modal) {
    closeDemo();
  }
});
