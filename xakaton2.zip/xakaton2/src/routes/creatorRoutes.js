import express from "express";
import {
  getAllCreators,
  getCreatorByType,
} from "../controllers/creatorController.js";

const router = express.Router();

router.get("/", getAllCreators);
router.get("/:type", getCreatorByType);

export default router;
