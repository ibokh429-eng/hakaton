import creators from "../data/creators.js";

export const getAllCreators = (req, res) => {
  const list = Object.values(creators);
  res.status(200).json({
    success: true,
    count: list.length,
    data: list,
  });
};

export const getCreatorByType = (req, res) => {
  const { type } = req.params;
  const creator = creators[type];

  if (!creator) {
    return res.status(404).json({
      success: false,
      error: `Creator with type "${type}" not found`,
    });
  }

  res.status(200).json({
    success: true,
    data: creator,
  });
};
