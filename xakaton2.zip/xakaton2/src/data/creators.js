const creators = {
  bloger: {
    type: "bloger",
    profession: "🎥 BLOGER",
    title: "🎥 Bloger",
    image: "images/blogger.png",
    imageAlt: "Bloger",
    heading: "Video uchun ssenariy tayyorlash",
    description:
      "Mavzunu kiriting. AI video uchun tayyor struktura va ssenariy yaratadi.",
    removedTasks: "g‘oya → reja → ssenariy",
    aiTask:
      "Video mavzusini qabul qiladi → mavzunu tahlil qiladi → ssenariy strukturasini yaratadi → tayyor ssenariy beradi.",
    stepsBefore: 7,
    stepsAfter: 1,
  },

  montajchi: {
    type: "montajchi",
    profession: "🎬 MONTAJCHI",
    title: "🎬 Montajchi",
    image: "images/montajchi.png",
    imageAlt: "Montajchi",
    heading: "Subtitrni avtomatik yaratish",
    description:
      "Videoni yuklang. AI ovozni aniqlaydi, matnga aylantiradi va subtitrni joylaydi.",
    removedTasks: "tinglash → yozish → joylash",
    aiTask:
      "Videoni qabul qiladi → ovozni aniqlaydi → matnga aylantiradi → subtitrni vaqt bo‘yicha joylashtiradi.",
    stepsBefore: 6,
    stepsAfter: 1,
  },

  rassom: {
    type: "rassom",
    profession: "🎨 RASSOM",
    title: "🎨 Rassom",
    image: "images/rassom.png",
    imageAlt: "Rassom",
    heading: "Rasmni kontent formatiga moslash",
    description:
      "Bitta rasmni yuklang. AI uni post, story va thumbnail formatlariga tayyorlaydi.",
    removedTasks: "o‘lchash → kesish → joylash",
    aiTask:
      "Bitta rasmni qabul qiladi → asosiy obyektni aniqlaydi → kerakli formatni tanlaydi → post/story/thumbnail variantlarini yaratadi.",
    stepsBefore: 5,
    stepsAfter: 1,
  },

  telegram: {
    type: "telegram",
    profession: "📢 TELEGRAM",
    title: "📢 Telegram kanal yurituvchi",
    image: "images/telegram.png",
    imageAlt: "Telegram kanal",
    heading: "Postni tayyorlash va rejalashtirish",
    description:
      "Oddiy ma'lumotni kiriting. AI unini tayyor Telegram postiga aylantiradi.",
    removedTasks: "yozish → formatlash → rejalash",
    aiTask:
      "Oddiy ma'lumotni qabul qiladi → matnni tartiblaydi → Telegram formatiga moslaydi → tayyor post yaratadi.",
    stepsBefore: 6,
    stepsAfter: 1,
  },
};

export default creators;
